#!/usr/bin/env bash
# ==============================================================================
# ASTERIX OS — OS-Computing & Host Collaboration Bridge (Bash Edition v3.0)
# Universal cross-platform bridge: Linux, Windows/Git-Bash, macOS, WSL, Termux.
# Zero external dependencies.
# ==============================================================================

set -e

C_RESET="\033[0m"
C_BOLD="\033[1m"
C_CYAN="\033[38;5;51m"
C_GREEN="\033[38;5;46m"
C_YELLOW="\033[38;5;220m"
C_RED="\033[38;5;196m"
C_MAGENTA="\033[38;5;201m"
C_WHITE="\033[38;5;231m"
C_BLUE="\033[38;5;45m"
C_GRAY="\033[38;5;244m"

VAULT_DIR="${HOME}/.asterix_vault/host_arsenal"
BIN_BRIDGE="${VAULT_DIR}/bin"
WORDLISTS_BRIDGE="${VAULT_DIR}/wordlists"

echo -e "${C_CYAN}${C_BOLD}╔══════════════════════════════════════════════════════════════════════════╗${C_RESET}"
echo -e "${C_CYAN}║${C_WHITE} ${C_BOLD}[ ASTERIX OS-COMPUTING // UNIVERSAL HOST COLLABORATION & BRIDGE v3.0 ]${C_RESET}${C_CYAN}    ║${C_RESET}"
echo -e "${C_CYAN}╚══════════════════════════════════════════════════════════════════════════╝${C_RESET}\n"

action="${1:-status}"

get_distro_name() {
    if [ -f "/etc/os-release" ]; then
        grep -E "^PRETTY_NAME=" /etc/os-release | cut -d= -f2 | tr -d '"' || echo "Linux"
    elif uname -s 2>/dev/null | grep -qi "MINGW\|MSYS\|CYGWIN"; then
        echo "Windows (NT Environment via $(uname -s))"
    elif [ "$(uname -s)" = "Darwin" ]; then
        echo "macOS $(sw_vers -productVersion 2>/dev/null || echo '')"
    else
        uname -s
    fi
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

case "$action" in
    probe|scan|detect)
        echo -e "  ${C_BOLD}HOST ENVIRONMENT & DUAL-BOOT RECONNAISSANCE:${C_RESET}\n"
        distro=$(get_distro_name)
        echo -e "  • Primary Host OS:   ${C_CYAN}${C_BOLD}${distro}${C_RESET}"
        echo -e "  • Kernel Release:    ${C_YELLOW}$(uname -r)${C_RESET}"
        echo -e "  • Architecture:      ${C_YELLOW}$(uname -m)${C_RESET}"
        cores=$(nproc 2>/dev/null || grep -c ^processor /proc/cpuinfo 2>/dev/null || echo "1")
        echo -e "  • Compute Cores:     ${C_GREEN}${cores} Cores Available${C_RESET}"
        
        # Check WSL
        if command -v wsl.exe >/dev/null 2>&1; then
            echo -e "  • WSL Engine:        ${C_GREEN}[ONLINE] Windows Subsystem for Linux available${C_RESET}"
        fi

        echo -e "\n  ${C_WHITE}Mounted Dual-Boot / External Partitions:${C_RESET}"
        found_mounts=0
        for m in /mnt/* /media/*; do
            if [ -d "$m" ]; then
                if [ -f "$m/etc/os-release" ]; then
                    part_name=$(grep -E "^PRETTY_NAME=" "$m/etc/os-release" | cut -d= -f2 | tr -d '"' || basename "$m")
                    echo -e "    • ${C_GREEN}[[OK]] Discovered: ${C_WHITE}${part_name}${C_RESET} at ${C_CYAN}${m}${C_RESET}"
                    found_mounts=$((found_mounts + 1))
                fi
            fi
        done
        [ $found_mounts -eq 0 ] && echo -e "    ${C_GRAY}[i] No separate Linux OS installations found in /mnt or /media.${C_RESET}"

        # Tools audit
        tools=(cargo rustc python3 python node npm git git-lfs nmap masscan amass msfconsole searchsploit sqlmap hydra john hashcat aircrack-ng wifite kismet wireshark tshark tcpdump burpsuite nikto gobuster ffuf radare2 ghidra binwalk foremost volatility exiftool steghide)
        avail=0
        for t in "${tools[@]}"; do
            command -v "$t" >/dev/null 2>&1 && avail=$((avail + 1))
        done
        echo -e "\n  ${C_WHITE}Native Tools Available on Host:${C_RESET} ${C_GREEN}${avail}/${#tools[@]} Verified${C_RESET}\n"
        ;;

    collaborate|bridge|sync|link|fuse|collab|host-collab)
        mkdir -p "$BIN_BRIDGE" "$WORDLISTS_BRIDGE" 2>/dev/null || true
        echo -e "  ${C_CYAN}[*] Synthesizing Cross-OS Security Bridge into: ${VAULT_DIR}...${C_RESET}\n"

        tools=(cargo rustc python3.14 python3 python node npm git git-lfs nmap masscan amass msfconsole searchsploit sqlmap hydra john hashcat aircrack-ng wifite kismet wireshark tshark tcpdump burpsuite nikto gobuster ffuf radare2 ghidra binwalk foremost volatility exiftool steghide curl wget)
        linked=0

        for t in "${tools[@]}"; do
            tool_path=$(command -v "$t" 2>/dev/null || true)
            if [ -n "$tool_path" ]; then
                if [ ! -e "$BIN_BRIDGE/$t" ]; then
                    ln -sf "$tool_path" "$BIN_BRIDGE/$t" 2>/dev/null && linked=$((linked + 1)) || true
                fi
            fi
        done

        # Map wordlists
        wl_linked=0
        for wdir in /usr/share/wordlists /usr/share/seclists "$HOME/wordlists" "$HOME/SecLists"; do
            if [ -d "$wdir" ]; then
                for f in "$wdir"/*; do
                    fname=$(basename "$f")
                    if [ ! -e "$WORDLISTS_BRIDGE/$fname" ]; then
                        ln -sf "$f" "$WORDLISTS_BRIDGE/$fname" 2>/dev/null && wl_linked=$((wl_linked + 1)) || true
                    fi
                done
            fi
        done

        echo -e "  ${C_GREEN}${C_BOLD}[[OK]] Cross-OS Collaboration Bridge Active!${C_RESET}"
        echo -e "    • Bridged Tools:     ${C_CYAN}${linked}${C_RESET} binaries linked into ${BIN_BRIDGE}"
        echo -e "    • Bridged Wordlists: ${C_CYAN}${wl_linked}${C_RESET} wordlist references mapped"
        echo -e "    • To activate now:   ${C_YELLOW}export PATH=\"${BIN_BRIDGE}:\$PATH\"${C_RESET}\n"
        ;;

    merge|os-merge|merge-os)
        if command -v python3 >/dev/null 2>&1 && [ -f "$SCRIPT_DIR/os_bridge.py" ]; then
            python3 "$SCRIPT_DIR/os_bridge.py" merge "$@"
        elif command -v python >/dev/null 2>&1 && [ -f "$SCRIPT_DIR/os_bridge.py" ]; then
            python "$SCRIPT_DIR/os_bridge.py" merge "$@"
        else
            echo -e "  ${C_CYAN}[*] Synthesizing Dual-OS Virtual Environment...${C_RESET}"
            mkdir -p "$HOME/.asterix_vault/merged_os/bin" "$HOME/.asterix_vault/merged_os/wordlists"
            cp -r "$BIN_BRIDGE"/* "$HOME/.asterix_vault/merged_os/bin/" 2>/dev/null || true
            echo -e "  ${C_GREEN}[[OK]] Dual-OS Merged Environment Active!${C_RESET}"
        fi
        ;;

    rebuild|os-rebuild|build-all|system-rebuild)
        if command -v python3 >/dev/null 2>&1 && [ -f "$SCRIPT_DIR/os_bridge.py" ]; then
            python3 "$SCRIPT_DIR/os_bridge.py" rebuild "$@"
        elif command -v python >/dev/null 2>&1 && [ -f "$SCRIPT_DIR/os_bridge.py" ]; then
            python "$SCRIPT_DIR/os_bridge.py" rebuild "$@"
        else
            echo -e "  ${C_CYAN}[*] Rebuilding ASTERIX OS Core Systems...${C_RESET}"
            bash "$0" merge
            echo -e "  ${C_GREEN}[[OK]] ASTERIX OS System Rebuilt & Verified!${C_RESET}"
        fi
        ;;

    compute|max-output|synergy)
        echo -e "  ${C_MAGENTA}${C_BOLD}[*] ENGAGING MAXIMUM COMPUTE & HARDWARE SYNERGY CORE...${C_RESET}\n"
        cores=$(nproc 2>/dev/null || grep -c ^processor /proc/cpuinfo 2>/dev/null || echo "1")
        echo -e "  • Hardware Concurrency:  ${C_GREEN}${cores} Threads Allocated${C_RESET}"
        echo -e "  • Dynamic OS Coupling:   ${C_CYAN}ASTERIX OS + Host Arsenal Interlinked${C_RESET}"
        echo -e "\n  ${C_GREEN}[[OK]] Compute synergy configured for maximum throughput.${C_RESET}\n"
        ;;

    imitate|persona)
        distro=$(get_distro_name)
        echo -e "  ${C_CYAN}[*] Adapting ASTERIX OS Persona for: ${C_WHITE}${distro}${C_RESET}...\n"
        if echo "$distro" | grep -qi "windows"; then
            echo -e "  ${C_CYAN}${C_BOLD}[PERSONA: CYBERNETIC WINDOWS SENTINEL]${C_RESET}"
            echo -e "  • Windows NT & PowerShell synergy active.\n"
        elif echo "$distro" | grep -qi "kali"; then
            echo -e "  ${C_CYAN}${C_BOLD}[PERSONA: KALI DRAGON TOTAL SYNERGY]${C_RESET}"
            echo -e "  • Kali tactical toolchain & wordlists bridged.\n"
        elif echo "$distro" | grep -qi "blackarch"; then
            echo -e "  ${C_RED}${C_BOLD}[PERSONA: BLACKARCH TOTAL WARFARE]${C_RESET}"
            echo -e "  • Multi-thousand package suite paths bridged.\n"
        else
            echo -e "  ${C_YELLOW}${C_BOLD}[PERSONA: UNIVERSAL CYBERNETIC CO-PROCESSOR]${C_RESET}"
            echo -e "  • Full multi-core compute synergy active.\n"
        fi
        ;;

    status|*)
        distro=$(get_distro_name)
        echo -e "  • Host Distribution:    ${C_CYAN}${C_BOLD}${distro}${C_RESET}"
        echo -e "  • Bridge Directory:     ${C_WHITE}${BIN_BRIDGE}${C_RESET}"
        bcount=$(ls -1 "$BIN_BRIDGE" 2>/dev/null | wc -l || echo "0")
        echo -e "  • Active Bridged Tools: ${C_GREEN}${bcount}${C_RESET}"
        echo -e "\n  ${C_YELLOW}Commands:${C_RESET}"
        echo -e "    ax os-computing probe        - Detect host OS, hardware & dual-boot installations"
        echo -e "    ax os-computing collaborate  - Bridge host & companion OS tools into ASTERIX"
        echo -e "    ax os-computing compute      - Maximize CPU/GPU compute synergy"
        echo -e "    ax os-computing imitate      - Synchronize UI persona with host OS\n"
        ;;
esac
