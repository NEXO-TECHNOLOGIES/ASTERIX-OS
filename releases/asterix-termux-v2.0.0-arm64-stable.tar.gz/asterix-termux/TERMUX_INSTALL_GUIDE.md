# [MOBILE] ASTERIX OS v2.0 'Phantom' — Termux ARM64 Install Guide

## Requirements
- Android 7.0 or later
- Termux (latest from F-Droid — NOT from Google Play Store)
- ~1.5 GB free storage (for Debian PRoot + tools)

## Step 1: Install Termux
Download from **F-Droid** (recommended):
> https://f-droid.org/packages/com.termux/

## Step 2: Transfer & Extract this Bundle
```bash
# Copy the bundle to your device, then inside Termux:
tar -xzf asterix-termux-v2.0.0-arm64-stable.tar.gz
cd asterix-termux/
```

## Step 3: Run the Installer
```bash
bash install-termux.sh
```
This automatically:
- Installs Debian PRoot rootless Linux environment
- Compiles the native Rust boot engine on your device
- Deploys the full ASTERIX OS inside Termux
- Sets up the `ax` master command dispatcher

## Step 4: Initialize ASTERIX
```bash
bash asterix-termux-init.sh
```

## Quick Commands After Install
```bash
ax help                      # Show all available commands
ax ai chat                   # Start conversational AI session
ax cam-hunter hotel          # Hotel privacy counter-surveillance sweep
ax self-evolve evolve        # Update AI knowledge from threat feeds
ax arsenal list              # Browse 180+ security tools
ax boot-tool dualboot 4      # Generate dual-boot USB files
```

## Default Credentials
- **User:** `asterix`
- **Password:** `asterix`

## Bundle Size
~312 MB compressed (core system)
~1.5 GB expanded (with Debian PRoot)
